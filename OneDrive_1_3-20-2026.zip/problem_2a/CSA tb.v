`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11.11.2025 17:49:50
// Design Name: 
// Module Name: CSA tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module carry_select_adder_tb;
reg [3:0]A;
reg [3:0]B;
reg cin;    
wire [3:0]S;
wire cout;

carry_select_adder DUT (
        .A(A),
        .B(B),
        .cin(cin),
        .S(S),
        .cout(cout)
    );
 
initial begin
A=4'b0000;
B=4'b0000;
cin=1'b0;
#10
A=4'b0000;
B=4'b0001;
cin=1'b0;
#10;
A=4'b0001;
B=4'b0001;
cin=1'b0;
#10;
A=4'b0111;
B=4'b1000;
cin=1'b0;
#10;
A=4'b1111;
B=4'b1111; 
cin = 1'b0;
#10;
A=4'b1111; 
B=4'b0000; 
cin=1'b1; 
#10;
$finish;
end
endmodule
