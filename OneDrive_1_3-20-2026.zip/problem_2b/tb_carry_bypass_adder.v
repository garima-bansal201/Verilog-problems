`timescale 1ns / 1ps

module tb_carry_bypass_adder;

reg [3:0] A, B;
reg Cin;
wire [3:0] Sum;
wire Cout;

carry_bypass_adder DUT (A, B, Cin, Sum, Cout);

initial begin
    $display("Time\tA\tB\tCin\t|\tSum\tCout");
    $monitor("%0t\t%b\t%b\t%b\t|\t%b\t%b",
              $time, A, B, Cin, Sum, Cout);

    A = 4'b0000; B = 4'b0000; Cin = 0; #10;
    A = 4'b0001; B = 4'b0001; Cin = 0; #10;
    A = 4'b0011; B = 4'b0011; Cin = 1; #10;
    A = 4'b0101; B = 4'b1010; Cin = 0; #10;
    A = 4'b1111; B = 4'b0001; Cin = 1; #10;

    repeat (10) begin
        A = $random;
        B = $random;
        Cin = $random % 2;
        #10;
    end

    $finish;
end

endmodule
