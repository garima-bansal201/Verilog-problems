module carry_bypass_adder(A, B, Cin, Sum, Cout);
    input  [3:0] A, B;
    input  Cin;
    output [3:0] Sum;
    output Cout;

    wire Cout_ripple;
    wire [3:0] P;
    wire P_block;

    assign P = A ^ B;
    assign P_block = &P;

    ripple_carry_adder_4 RCA (
        .A(A),
        .B(B),
        .Cin(Cin),
        .Sum(Sum),
        .Cout(Cout_ripple)
    );

    assign Cout = (P_block) ? Cin : Cout_ripple;
endmodule
